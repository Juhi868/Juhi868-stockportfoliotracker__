const stockPrices = {
    "AAPL": 180,
    "TSLA": 250,
    "GOOG": 140,
    "MSFT": 300,
    "AMZN": 120
};

let grandTotal = 0;

function addStock() {
    const stock = document.getElementById("stock").value;
    const quantity = parseInt(document.getElementById("quantity").value);

    if (!quantity || quantity <= 0) {
        alert("Please enter a valid quantity");
        return;
    }

    const price = stockPrices[stock];
    const total = price * quantity;
    grandTotal += total;

    const table = document.getElementById("portfolioTable");
    const row = table.insertRow();

    row.insertCell(0).innerText = stock;
    row.insertCell(1).innerText = quantity;
    row.insertCell(2).innerText = price;
    row.insertCell(3).innerText = total;

    document.getElementById("grandTotal").innerText =
        "Total Investment: $" + grandTotal;

    document.getElementById("quantity").value = "";
}
